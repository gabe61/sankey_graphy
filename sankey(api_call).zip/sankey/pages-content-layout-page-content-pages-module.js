(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-content-layout-page-content-pages-module"],{

/***/ "./src/app/pages/content-layout-page/content-layout-page.component.html":
/*!******************************************************************************!*\
  !*** ./src/app/pages/content-layout-page/content-layout-page.component.html ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">\r\n\t<div id=\"kick-start\" class=\"card col-md-12 col-sm-12\">\r\n\t\t<div class=\"card-header\">\r\n\t\t\t<h4 class=\"card-title\">IDC network traffic(TX)</h4>\r\n\t\t</div>\r\n\t\t<div class=\"card-body\" style=\"height: 600px;\">\r\n\t\t\t<div id=\"chartdivTX\" class=\"chartdiv\"></div>\r\n\t\t</div>\r\n\t</div>\r\n\t<div id=\"kick-start\" class=\"card col-md-12 col-sm-12\">\r\n\t\t<div class=\"card-header\">\r\n\t\t\t<h4 class=\"card-title\">IDC network traffic(RX)</h4>\r\n\t\t</div>\r\n\t\t<div class=\"card-body\">\r\n\t\t\t<div id=\"chartdivRX\" class=\"chartdiv\"></div>\r\n\t\t</div>\r\n\t</div>\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/pages/content-layout-page/content-layout-page.component.scss":
/*!******************************************************************************!*\
  !*** ./src/app/pages/content-layout-page/content-layout-page.component.scss ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".chartdiv {\n  width: 100%;\n  height: 500px; }\n"

/***/ }),

/***/ "./src/app/pages/content-layout-page/content-layout-page.component.ts":
/*!****************************************************************************!*\
  !*** ./src/app/pages/content-layout-page/content-layout-page.component.ts ***!
  \****************************************************************************/
/*! exports provided: ContentLayoutPageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContentLayoutPageComponent", function() { return ContentLayoutPageComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _amcharts_amcharts4_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @amcharts/amcharts4/core */ "./node_modules/@amcharts/amcharts4/core.js");
/* harmony import */ var _amcharts_amcharts4_charts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @amcharts/amcharts4/charts */ "./node_modules/@amcharts/amcharts4/charts.js");
/* harmony import */ var _amcharts_amcharts4_themes_animated__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @amcharts/amcharts4/themes/animated */ "./node_modules/@amcharts/amcharts4/themes/animated.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




var ContentLayoutPageComponent = /** @class */ (function () {
    function ContentLayoutPageComponent() {
        this.Graph_path = [
            { key: 'C', from: "C9300", to: "N7K", value: 3, labelText_X: "From C9300 to N7K", labelText_Y: "From C9300 to N7K", start: "C9300", end: "N7K", zIndex: 100, color: "#f47b20" },
            { key: 'A', from: "C9300", to: "SRX", value: 2, labelText_X: "From C9300 to SRX", labelText_Y: "From C9300 to N7K", start: "C9300", end: "SRX", zIndex: 100, color: "#f47b20" },
            { key: 'E', from: "N7K", to: "3950", value: 2, labelText_X: "From N7K to 3950", labelText_Y: "From C9300 to N7K", start: "N7K", end: "3950", zIndex: 100, color: "#f47b20" },
            { key: 'D', from: "N7K", to: "FORTI", value: 1.2, labelText_X: "From N7K to N7KI", labelText_Y: "From C9300 to N7K", start: "N7K", end: "FORTI", color: "#f47b20" },
            { key: 'G', from: "3950", to: "GIGAMONT", value: 2.4, labelText_X: "From 3950 to GIGAMONT", labelText_Y: "From C9300 to N7K", start: "3950", end: "GIGAMONT", zIndex: 100, color: "#f47b20" },
            { key: 'F', from: "FORTI", to: "C9300'", value: 2, labelText_X: "From N7KI to C9300", labelText_Y: "From C9300 to N7K", start: "FORTI", end: "C9300", zIndex: 100, color: "#f47b20" },
            // { key:'K', from: "SRX:C9300", to: "SRX:C9300.", value: 1.5 ,labelText_X:"From SRX to C9300", labelText_Y:"From C9300 to N7K", start: "SRX", end: "C9300", zIndex: 100, color:"#f47b20" },
            { key: 'H', from: "GIGAMONT", to: "PA", value: 1.4, labelText_X: "From GIGAMONT to PA", labelText_Y: "From C9300 to N7K", start: "GIGAMONT", end: "PA", zIndex: 100, color: "#f47b20" },
            { key: 'I', from: "GIGAMONT", to: "GIGAMONT:9300", value: 2, labelText_X: "From GIGAMONT to C9300", labelText_Y: "From C9300 to N7K", start: "GIGAMONT", end: "C9300", zIndex: 100, color: "#f47b20" },
            // { key:'L', from: "SRX:C9300.", to: "SRX.:C9300.", value: 1.5 ,labelText_X:"From SRX to C9300", labelText_Y:"From C9300 to N7K", start: "SRX", end: "C9300", zIndex: 100, color:"#f47b20" },
            { key: 'J', from: "GIGAMONT:9300", to: "C9300.", value: 2, labelText_X: "to C9300", labelText_Y: "From C9300 to N7K", start: "GIGAMONT", end: "C9300", labelLocation: 0, labelRotation: -90, zIndex: 100, color: "#000000" },
            { key: 'B', from: "SRX", to: "C9300.", value: 1.5, labelText_X: "From SRX to C9300", labelText_Y: "From C9300 to N7K", start: "SRX", end: "C9300", labelLocation: 0, labelRotation: -90, zIndex: 1000, color: "#000000" },
        ];
        this.time = 1;
        this.setintervaltime = 30000;
        this.initial_flag = true;
    }
    ContentLayoutPageComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.callIDCTX();
        setInterval(function () {
            _this.callIDCTX();
        }, this.setintervaltime);
        this.callIDCRX();
        // setInterval(() => { this.temple_function();}, 30000);
        console.log('content-layout');
        this.modifyLabelText();
    };
    ContentLayoutPageComponent.prototype.ngAfterViewInit = function () {
    };
    ContentLayoutPageComponent.prototype.modifyLabelText = function () {
        // setTimeout( () => {
        //     // $("text tspan:contains(C9300``)").text("SRX->C9300");
        //     // $("text tspan:contains(C9300.`')").text("SRX->C9300");
        //     // $("text tspan:contains(C9300')").text("SRX->C9300");
        //     // $("text tspan:contains(C9300`)").text("GIGAMONT->C9300");
        // }, 1000);
        // <tspan>C9300``</tspan>
    };
    ContentLayoutPageComponent.prototype.temple_function = function () {
        this.callIDCTX();
        this.callIDCRX();
    };
    ContentLayoutPageComponent.prototype.callIDCTX = function () {
        var chartTX;
        _amcharts_amcharts4_core__WEBPACK_IMPORTED_MODULE_1__["useTheme"](_amcharts_amcharts4_themes_animated__WEBPACK_IMPORTED_MODULE_3__["default"]);
        chartTX = _amcharts_amcharts4_core__WEBPACK_IMPORTED_MODULE_1__["create"]("chartdivTX", _amcharts_amcharts4_charts__WEBPACK_IMPORTED_MODULE_2__["SankeyDiagram"]);
        // time!
        chartTX.hiddenState.properties.opacity = 0.5;
        // chartTX.data = this.Graph_path;
        // if(this.initial_flag){
        chartTX.data = this.callAPIData('tx', 2);
        // console.log('inited1', chartTX.links.getIndex(1).dataItem.toNode);
        chartTX.events.on("ready", function () {
            console.log('inited1', chartTX.links.getIndex(1).dataItem.toNode);
            for (var i = 0; i < chartTX.links.length; i++) {
                var link = chartTX.links.getIndex(i);
                var bullet = link.bullets.getIndex(1);
                bullet.opacity = 0;
                if (link.dataItem.toNode && link.dataItem.value > 10) {
                    bullet.label.fontSize = link.dataItem.value;
                    firstHalfAnimation(bullet);
                }
                else {
                    link.bullets.removeValue(bullet);
                }
            }
        });
        var hoverStateTX = chartTX.links.template.states.create("hover");
        hoverStateTX.properties.fillOpacity = 1;
        chartTX.paddingRight = 30;
        chartTX.paddingTop = 80;
        chartTX.paddingBottom = 80;
        chartTX.nodeAlign = "bottom";
        chartTX.minNodeSize = 0.001;
        //
        chartTX.dataFields.fromName = "from";
        chartTX.dataFields.toName = "to";
        chartTX.dataFields.fromNode = "start";
        chartTX.dataFields.toNode = "end";
        chartTX.dataFields.color = "color";
        chartTX.dataFields.value = "value_tx2";
        chartTX.dataFields.key = "key";
        chartTX.dataFields.start = "start";
        chartTX.dataFields.end = "end";
        chartTX.dataFields.visible = false;
        chartTX.paddingRight = 30;
        //gradient
        var linkTemplate = chartTX.links.template;
        linkTemplate.colorMode = "gradient";
        linkTemplate.fillOpacity = 1;
        linkTemplate.cursorOverStyle = _amcharts_amcharts4_core__WEBPACK_IMPORTED_MODULE_1__["MouseCursorStyle"].pointer;
        linkTemplate.showSystemTooltip = true;
        linkTemplate.propertyFields.zIndex = "zIndex";
        linkTemplate.tension = 0.6;
        linkTemplate.colorMode = "gradient";
        linkTemplate.tooltipText = "Traffic Data Points from {start} to {end} \n{start} → {end}: [bold]{value_tx1}[/] Gbytes\n";
        // linkTemplate.strokeOpacity = 1;
        // making links draggable
        linkTemplate.events.on("down", function (event) {
            var fromNode = event.target.dataItem.fromNode;
            var toNode = event.target.dataItem.toNode;
            var distanceToFromNode = _amcharts_amcharts4_core__WEBPACK_IMPORTED_MODULE_1__["math"].getDistance(event.pointer.point, { x: fromNode.pixelX, y: fromNode.pixelY });
            var distanceToToNode = Infinity;
            if (toNode) {
                distanceToToNode = _amcharts_amcharts4_core__WEBPACK_IMPORTED_MODULE_1__["math"].getDistance(event.pointer.point, { x: toNode.pixelX, y: toNode.pixelY });
            }
            if (distanceToFromNode < distanceToToNode) {
                fromNode.dragStart(event.pointer);
            }
            else {
                toNode.dragStart(event.pointer);
            }
        });
        //configure links
        // chartTX.links.template.tooltipHTML = '<p style="text-align: center;">Traffic Data Points from {start} to {end} <br>{start} → {end}: <bold style="font-size:20px">{value_tx1}/</bold>Gbytes <br></p>';
        // chartTX.links.template.fromString = "{{start}}";
        // chartTX.links.template.toStringTag = "{{end}}";
        var hoverState = chartTX.links.template.states.create("hover");
        hoverState.properties.fillOpacity = 1;
        // hoverState.properties.strokeOpacity = 1;
        // make nodes draggable
        var nodeTemplateTX = chartTX.nodes.template;
        //disable names
        // nodeTemplateTX.nameLabel.disabled = true;
        nodeTemplateTX.nameLabel.disabled = false;
        nodeTemplateTX.draggable = true;
        nodeTemplateTX.inert = true;
        nodeTemplateTX.togglable = false;
        nodeTemplateTX.width = 10;
        // nodeTemplateTX.stroke = am4core.color("#fff"); // stroke
        nodeTemplateTX.strokeWidth = 1;
        nodeTemplateTX.nameLabel.label.fontWeight = "bold";
        nodeTemplateTX.nameLabel.adapter.add("locationX", function (location, target) {
            switch (target.parent.level) {
                case 0:
                    return 1;
                case 5:
                    return -6;
                default:
                    return -2;
            }
        });
        // add labels
        var labelBullet = chartTX.links.template.bullets.push(new _amcharts_amcharts4_charts__WEBPACK_IMPORTED_MODULE_2__["LabelBullet"]());
        labelBullet.label.propertyFields.text = "labelText";
        labelBullet.propertyFields.locationX = "labelLocation";
        labelBullet.propertyFields.rotation = "labelLocation";
        labelBullet.label.horizontalCenter = "left";
        labelBullet.label.textAlign = "start";
        labelBullet.label.dx = -50;
        // add labels which will animate
        var bullet = chartTX.links.template.bullets.push(new _amcharts_amcharts4_charts__WEBPACK_IMPORTED_MODULE_2__["LabelBullet"]());
        bullet.label.text = "{value}GB";
        bullet.label.fill = _amcharts_amcharts4_core__WEBPACK_IMPORTED_MODULE_1__["color"]("#ffffff");
        bullet.label.isMeasured = false;
        bullet.isMeasured = false;
        // create animations
        function firstHalfAnimation(bullet) {
            var duration = 5000;
            var animation = bullet.animate([{ property: "locationX", from: 0.2, to: 0.5 }, { property: "opacity", from: 0, to: 0.3 }], duration);
            animation.events.on("animationended", function (event) {
                secondHalfAnimation(event.target.object, duration);
            });
        }
        function secondHalfAnimation(bullet, duration) {
            var animation = bullet.animate([{ property: "locationX", from: 0.5, to: 0.8 }, { property: "opacity", from: 0.3, to: 0 }], duration);
            animation.events.on("animationended", function (event) {
                // setTimeout(function () {
                //     firstHalfAnimation(event.target.object)
                // }, 5000);
            });
        }
    };
    /**
     *  RX Graph
     * **/
    ContentLayoutPageComponent.prototype.callIDCRX = function () {
        var _this = this;
        var chartRX;
        _amcharts_amcharts4_core__WEBPACK_IMPORTED_MODULE_1__["useTheme"](_amcharts_amcharts4_themes_animated__WEBPACK_IMPORTED_MODULE_3__["default"]);
        chartRX = _amcharts_amcharts4_core__WEBPACK_IMPORTED_MODULE_1__["create"]("chartdivRX", _amcharts_amcharts4_charts__WEBPACK_IMPORTED_MODULE_2__["SankeyDiagram"]);
        chartRX.hiddenState.properties.opacity = 0;
        if (this.initial_flag) {
            chartRX.data = this.callAPIData('rx', 2);
            this.initial_flag = false;
        }
        setInterval(function () {
            {
                // console.log('setintervalrx', this.time);
                if (_this.time == 1) {
                    chartRX.data = _this.callAPIData('rx', 1);
                    // this.time = 2;
                }
                else if (_this.time == 2) {
                    chartRX.data = _this.callAPIData('rx', 2);
                    // this.time = 1;
                }
            }
        }, this.setintervaltime);
        // if(this.time == 1) {
        //     chartRX.data = this.callAPIData ('rx', 1);
        // }else if(this.time == 2){
        //     chartRX.data = this.callAPIData ('rx', 2);
        // }
        var hoverStateRX = chartRX.links.template.states.create("hover");
        hoverStateRX.properties.fillOpacity = 0.6;
        chartRX.dataFields.fromName = "from";
        chartRX.dataFields.toName = "to";
        chartRX.dataFields.value = "value_rx2";
        chartRX.dataFields.key = "key";
        chartRX.dataFields.start = "start";
        chartRX.dataFields.end = "end";
        var labelBullet = chartRX.links.template.bullets.push(new _amcharts_amcharts4_charts__WEBPACK_IMPORTED_MODULE_2__["LabelBullet"]());
        labelBullet.label.propertyFields.text = "labelText";
        chartRX.paddingRight = 30;
        //configure links
        chartRX.links.template.colorMode = "gradient";
        chartRX.links.template.tooltipText = "Traffic Data Points from {start} to {end} \n{start} → {end}: [bold]{value_rx1}[/] Gbytes\n";
        // chartRX.links.template.tooltipHTML = '<p>Traffic Data Points from {start} to {end} <br>{start} → {end}: <bold>{value_tx1}/</bold>Gbytes <br></p>';
        var hoverState = chartRX.links.template.states.create("hover");
        hoverState.properties.fillOpacity = 1;
        //test
        // make nodes draggable
        var nodeTemplateTX = chartRX.nodes.template;
        //disable names
        nodeTemplateTX.nameLabel.disabled = false;
        nodeTemplateTX.inert = true;
        // nodeTemplateTX.readerTitle = "Drag me!";
        // nodeTemplateTX.showSystemTooltip = true;
        nodeTemplateTX.width = 10;
        nodeTemplateTX.stroke = _amcharts_amcharts4_core__WEBPACK_IMPORTED_MODULE_1__["color"]("#fff");
        nodeTemplateTX.strokeWidth = 1;
        nodeTemplateTX.nameLabel.label.fontWeight = "bold";
        nodeTemplateTX.nameLabel.adapter.add("locationX", function (location, target) {
            switch (target.parent.level) {
                case 0:
                    return 1;
                case 5:
                    return -6;
                default:
                    return -2;
            }
        });
    };
    /**
     *  get the API in time
     *  param:
     *      val: tx, rx
     *      step_val: 1, 2, 3(time)
     * */
    ContentLayoutPageComponent.prototype.callAPIData = function (val, step_val) {
        /**
         *  define the current value and past value.
         *  3/1/2019
         * */
        var current_val, before_val;
        var temp_array = [
            // value of 1551418869
            [{ "timestamp": 1551418869, "traffic_path": "A", "tx": 51961504459, "rx": 92078796286 },
                { "timestamp": 1551418869, "traffic_path": "C1", "tx": 16992981837, "rx": 130371344367 },
                { "timestamp": 1551418869, "traffic_path": "E", "tx": 3910806571540603, "rx": 1137537341394269 },
                { "timestamp": 1551418870, "traffic_path": "H", "tx": 270296082399351, "rx": 267217474359544 },
                { "timestamp": 1551418869, "traffic_path": "B", "tx": 110713762875, "rx": 241973697963 },
                { "timestamp": 1551418869, "traffic_path": "C", "tx": 940837739366791, "rx": 341823112459116 },
                { "timestamp": 1551418869, "traffic_path": "D", "tx": 367931324550768, "rx": 629451566912481 },
                { "timestamp": 1551418869, "traffic_path": "F", "tx": 380644350540307, "rx": 903516359649354 },
                { "timestamp": 1551418869, "traffic_path": "G", "tx": 4216840074281697, "rx": 1991927424284454 },
                { "timestamp": 1551418870, "traffic_path": "H1", "tx": 273375720081395, "rx": 268351242687960 },
                { "timestamp": 1551418869, "traffic_path": "I", "tx": 747062840982295, "rx": 279598088821163 }],
            // value of 1551419089
            [{ "timestamp": 1551419089, "traffic_path": "C", "tx": 940848512406163, "rx": 341826805521474 },
                { "timestamp": 1551419089, "traffic_path": "C1", "tx": 16993178995, "rx": 130371916701 },
                { "timestamp": 1551419089, "traffic_path": "D", "tx": 367931859092364, "rx": 629451968148799 },
                { "timestamp": 1551419089, "traffic_path": "E", "tx": 3910810341276682, "rx": 1137537806445517 },
                { "timestamp": 1551419089, "traffic_path": "G", "tx": 4216844744768551, "rx": 1991929983878572 },
                { "timestamp": 1551419090, "traffic_path": "H1", "tx": 273380252121137, "rx": 268355745852360 },
                { "timestamp": 1551419088, "traffic_path": "A", "tx": 51961504459, "rx": 92078796286 },
                { "timestamp": 1551419089, "traffic_path": "B", "tx": 110713762875, "rx": 241973697963 },
                { "timestamp": 1551419089, "traffic_path": "F", "tx": 380645292639514, "rx": 903516984791866 },
                { "timestamp": 1551419090, "traffic_path": "H", "tx": 270302035932138, "rx": 267223392904722 },
                { "timestamp": 1551419089, "traffic_path": "I", "tx": 747073722832275, "rx": 279602047106384 }],
            // value of 1551419169
            [{ "timestamp": 1551419169, "traffic_path": "A", "tx": 51961504459, "rx": 92078796286 },
                { "timestamp": 1551419169, "traffic_path": "C1", "tx": 16992981837, "rx": 130371344367 },
                { "timestamp": 1551419169, "traffic_path": "E", "tx": 3910806571540603, "rx": 1137537341394269 },
                { "timestamp": 1551419170, "traffic_path": "H", "tx": 270296082399351, "rx": 267217474359544 },
                { "timestamp": 1551419169, "traffic_path": "B", "tx": 110713762875, "rx": 241973697963 },
                { "timestamp": 1551419169, "traffic_path": "C", "tx": 940837739366791, "rx": 341823112459116 },
                { "timestamp": 1551419169, "traffic_path": "D", "tx": 367931324550768, "rx": 629451566912481 },
                { "timestamp": 1551419169, "traffic_path": "F", "tx": 380644350540307, "rx": 903516359649354 },
                { "timestamp": 1551419169, "traffic_path": "G", "tx": 4216840074281697, "rx": 1991927424284454 },
                { "timestamp": 1551419170, "traffic_path": "H1", "tx": 273375720081395, "rx": 268351242687960 },
                { "timestamp": 1551419169, "traffic_path": "I", "tx": 747062840982295, "rx": 279598088821163 }]
        ];
        // var temp_array =[
        //     [{"timestamp":1551882626,"traffic_path":"B","tx":110713762875,"rx":241973697963},
        //     {"timestamp":1551882626,"traffic_path":"D","tx":369765762597339,"rx":631791093611303},
        //     {"timestamp":1551882626,"traffic_path":"E1","tx":3570802279759679,"rx":1420363389612970},
        //     {"timestamp":1551882626,"traffic_path":"G1","tx":4276858413431940,"rx":2010989878271061},
        //     {"timestamp":1551882627,"traffic_path":"H","tx":317528512554397,"rx":313949442566944},
        //     {"timestamp":1551882627,"traffic_path":"H1","tx":316735232996207,"rx":311171604326011},
        //     {"timestamp":1551882626,"traffic_path":"I","tx":871019093844506,"rx":315966537474072},
        //     {"timestamp":1551882626,"traffic_path":"A","tx":51961504459,"rx":92078796286},
        //     {"timestamp":1551882626,"traffic_path":"C1","tx":18609018551,"rx":135770155621},
        //     {"timestamp":1551882626,"traffic_path":"C","tx":1060895750868698,"rx":376546110214168},
        //     {"timestamp":1551882626,"traffic_path":"E2","tx":3590623321060809,"rx":1657974059281335},
        //     {"timestamp":1551882626,"traffic_path":"E3","tx":3863442867105981,"rx":996125701423256},
        //     {"timestamp":1551882626,"traffic_path":"G","tx":4276858413431940,"rx":2010989878271061},
        //     {"timestamp":1551882626,"traffic_path":"F","tx":384418944609566,"rx":908372817133701},
        //     {"timestamp":1551882626,"traffic_path":"E","tx":3877484291465537,"rx":869960794002498}],
        //
        //     [{"timestamp":1551882626,"traffic_path":"B","tx":110713762175,"rx":241973697363},
        //     {"timestamp":1551882626,"traffic_path":"D","tx":369765762597139,"rx":631791093611103},
        //     {"timestamp":1551882626,"traffic_path":"E1","tx":3570802279752679,"rx":1420363389612270},
        //     {"timestamp":1551882626,"traffic_path":"G1","tx":4276858413431540,"rx":2010989878271461},
        //     {"timestamp":1551882627,"traffic_path":"H","tx":317528512551197,"rx":313949442566644},
        //     {"timestamp":1551882627,"traffic_path":"H1","tx":316735232996707,"rx":311171604326111},
        //     {"timestamp":1551882626,"traffic_path":"I","tx":871019093844106,"rx":315966537474172},
        //     {"timestamp":1551882626,"traffic_path":"A","tx":51961504159,"rx":92078796686},
        //     {"timestamp":1551882626,"traffic_path":"C1","tx":18609018151,"rx":135770155121},
        //     {"timestamp":1551882626,"traffic_path":"C","tx":1060895750868298,"rx":376546110214468},
        //     {"timestamp":1551882626,"traffic_path":"E2","tx":3590623321060209,"rx":1657974059281135},
        //     {"timestamp":1551882626,"traffic_path":"E3","tx":3863442867105781,"rx":996125701423156},
        //     {"timestamp":1551882626,"traffic_path":"G","tx":4276858413431740,"rx":2010989878271261},
        //     {"timestamp":1551882626,"traffic_path":"F","tx":384418944609466,"rx":908372817133301},
        //     {"timestamp":1551882626,"traffic_path":"E","tx":3877484291465537,"rx":869960794002598}],
        //     [{"timestamp":1551882626,"traffic_path":"B","tx":110713762875,"rx":241973697963},
        //         {"timestamp":1551882626,"traffic_path":"D","tx":369765762597339,"rx":631791093611303},
        //         {"timestamp":1551882626,"traffic_path":"E1","tx":3570802279759679,"rx":1420363389612970},
        //         {"timestamp":1551882626,"traffic_path":"G1","tx":4276858413431940,"rx":2010989878271061},
        //         {"timestamp":1551882627,"traffic_path":"H","tx":317528512554397,"rx":313949442566944},
        //         {"timestamp":1551882627,"traffic_path":"H1","tx":316735232916207,"rx":311171604326011},
        //         {"timestamp":1551882626,"traffic_path":"I","tx":871019093844506,"rx":315966537474072},
        //         {"timestamp":1551882626,"traffic_path":"A","tx":51961504459,"rx":92078796286},
        //         {"timestamp":1551882626,"traffic_path":"C1","tx":18609018551,"rx":135770155621},
        //         {"timestamp":1551882626,"traffic_path":"C","tx":1060895750868698,"rx":376546110214168},
        //         {"timestamp":1551882626,"traffic_path":"E2","tx":3590623321060809,"rx":1657974059281335},
        //         {"timestamp":1551882626,"traffic_path":"E3","tx":3863442867105981,"rx":996125701423256},
        //         {"timestamp":1551882626,"traffic_path":"G","tx":4276858413431940,"rx":2010989878271061},
        //         {"timestamp":1551882626,"traffic_path":"F","tx":384418944609566,"rx":908372817133701},
        //         {"timestamp":1551882626,"traffic_path":"E","tx":3877484291465537,"rx":869960794002498}],
        // ];
        var retVal = [];
        var step_loop = [];
        var temp;
        var filter, seek_filter;
        /**
         *   filter the data
         * */
        // console.log('==>',temp_array);
        if (step_val === 1) {
            current_val = temp_array[1];
            before_val = temp_array[0];
        }
        else if (step_val === 2) {
            current_val = temp_array[2];
            before_val = temp_array[1];
        }
        for (var i = 0; i < current_val.length; i++) {
            for (var k = i + 1; k < current_val.length; k++) {
                if (current_val[i].traffic_path === current_val[k].traffic_path)
                    continue;
                if (current_val[i].traffic_path[0] === current_val[k].traffic_path[0] && current_val[i].traffic_path.length === 1) {
                    // console.log('==>', current_val[i].traffic_path, current_val[k].traffic_path);
                    current_val[i].tx += current_val[k].tx;
                    current_val[i].rx += current_val[k].rx;
                    current_val[k].tx = current_val[i].tx;
                    current_val[k].rx = current_val[i].rx;
                }
                // if(filter.traffic_path )
            }
        }
        for (var i = 0; i < before_val.length; i++) {
            for (var k = i + 1; k < before_val.length; k++) {
                if (before_val[i].traffic_path === before_val[k].traffic_path)
                    continue;
                if (before_val[i].traffic_path[0] === before_val[k].traffic_path[0]) {
                    // console.log('==>', filter.traffic_path, seek_filter);
                    before_val[i].tx += before_val[k].tx;
                    before_val[i].rx += before_val[k].rx;
                    before_val[k].tx = before_val[i].tx;
                    before_val[k].rx = before_val[i].rx;
                }
                // if(filter.traffic_path )
            }
        }
        // console.log('current_val', current_val);
        /**
         *   get the difference between tx1 and tx2, rx1 and rx2
         *   2019/3/1
         */
        // new version
        for (var _i = 0, before_val_1 = before_val; _i < before_val_1.length; _i++) {
            var step_one = before_val_1[_i];
            for (var _a = 0, current_val_1 = current_val; _a < current_val_1.length; _a++) {
                var step_two = current_val_1[_a];
                temp = step_one;
                if (temp.traffic_path == step_two.traffic_path) {
                    temp.tx = Math.abs(temp.tx - step_two.tx); ///(step_two.timestamp - temp.timestamp);
                    temp.rx = Math.abs(temp.rx - step_two.rx); ///(step_two.timestamp - temp.timestamp);
                    step_loop.push(temp);
                }
            }
        }
        /**
         *  insert tx and rx into the graph array
         *   2019/3/1
         */
        var min_val = 9999999999999999999;
        var max_val = 0;
        if (val == 'tx') {
            for (var _b = 0, step_loop_1 = step_loop; _b < step_loop_1.length; _b++) {
                var api_value = step_loop_1[_b];
                if (min_val > api_value.tx)
                    min_val = api_value.tx;
                if (max_val < api_value.tx)
                    max_val = api_value.tx;
            }
            // console.log('min-max', min_val, max_val);
            // console.log('--------->', step_loop, this.Graph_path);
            for (var _c = 0, _d = this.Graph_path; _c < _d.length; _c++) {
                var chart_value = _d[_c];
                for (var _e = 0, step_loop_2 = step_loop; _e < step_loop_2.length; _e++) {
                    var api_value = step_loop_2[_e];
                    temp = chart_value;
                    // console.log('===>',  chart_value.key, api_value.traffic_path);
                    if (api_value.traffic_path == chart_value.key) {
                        // temp['value_tx1'] = (api_value.tx)/1048576;
                        temp['value_tx1'] = Math.round((api_value.tx) * 100 / 1048576 / 1024) / 100;
                        temp['value_tx2'] = Math.round((api_value.tx) * 100 / 1048576 / 1024) / 100;
                        temp['labelText'] = Math.round((api_value.tx) * 100 / 1048576 / 1024) / 100 + 'GB';
                        // temp['value_tx2'] = (api_value.tx+1048576)/1048576;
                        // console.log('->', temp);
                        // temp.value = api_value.tx;
                        retVal.push(temp);
                    }
                    else if (api_value.traffic_path === 'I' && chart_value.key === 'J') {
                        // temp.key = 'J';
                        // temp['value_tx1'] = (api_value.tx)/1048576;
                        temp['value_tx1'] = Math.round((api_value.tx) * 100 / 1048576 / 1024) / 100;
                        temp['value_tx2'] = Math.round((api_value.tx) * 100 / 1048576 / 1024) / 100;
                        temp['labelText'] = Math.round((api_value.tx) * 100 / 1048576 / 1024) / 100 + 'GB';
                        // temp['value_tx2'] = (api_value.tx+1048576)/1048576;
                        // console.log('->', temp);
                        // temp.value = api_value.tx;
                        retVal.push(temp);
                    }
                    else if (api_value.traffic_path === 'B') {
                        if (chart_value.key === 'K' || chart_value.key === 'L' || chart_value.key === 'M') {
                            temp['value_tx1'] = Math.round((api_value.tx) * 100 / 1048576 / 1024) / 100;
                            temp['value_tx2'] = Math.round((api_value.tx) * 100 / 1048576 / 1024) / 100;
                            temp['labelText'] = Math.round((api_value.tx) * 100 / 1048576 / 1024) / 100 + 'GB';
                            retVal.push(temp);
                        }
                    }
                }
            }
        }
        else if (val == 'rx') {
            for (var _f = 0, _g = this.Graph_path; _f < _g.length; _f++) {
                var chart_value = _g[_f];
                for (var _h = 0, step_loop_3 = step_loop; _h < step_loop_3.length; _h++) {
                    var api_value = step_loop_3[_h];
                    if (api_value.traffic_path == chart_value.key) {
                        temp = chart_value;
                        // temp['value_tx1'] = (api_value.tx)/1048576;
                        temp['value_rx1'] = Math.round((api_value.rx) * 100 / 1048576 / 1024) / 100;
                        temp['value_rx2'] = Math.round((api_value.rx) * 100 / 1048576 / 1024) / 100;
                        temp['labelText'] = Math.round((api_value.rx) * 100 / 1048576 / 1024) / 100 + 'GB';
                        // temp['value_rx2'] = (api_value.rx+1048576)/1048576;
                        // console.log('->', temp);
                        // temp.value = api_value.rx;
                        retVal.push(temp);
                    }
                    if (api_value.traffic_path === 'I' && chart_value.key === 'J') {
                        temp = chart_value;
                        // temp.key = 'J';
                        // temp['value_rx1'] = (api_value.rx)/1048576;
                        temp['value_rx1'] = Math.round((api_value.rx) * 100 / 1048576 / 1024) / 100;
                        temp['value_rx2'] = Math.round((api_value.rx) * 100 / 1048576 / 1024) / 100;
                        temp['labelText'] = Math.round((api_value.rx) * 100 / 1048576 / 1024) / 100 + 'GB';
                        // temp['value_rx2'] = (api_value.rx+1048576)/1048576;
                        // console.log('->', temp);
                        // temp.value = api_value.rx;
                        retVal.push(temp);
                    }
                    else if (api_value.traffic_path === 'B') {
                        if (chart_value.key === 'K' || chart_value.key === 'L' || chart_value.key === 'M') {
                            temp = chart_value;
                            temp['value_rx1'] = Math.round((api_value.rx) * 100 / 1048576 / 1024) / 100;
                            temp['value_rx2'] = Math.round((api_value.rx) * 100 / 1048576 / 1024) / 100;
                            temp['labelText'] = Math.round((api_value.rx) * 100 / 1048576 / 1024) / 100 + 'GB';
                            retVal.push(temp);
                        }
                    }
                }
            }
        }
        // console.log('======>',retVal);
        return retVal;
    };
    ContentLayoutPageComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-content-layout-page',
            template: __webpack_require__(/*! ./content-layout-page.component.html */ "./src/app/pages/content-layout-page/content-layout-page.component.html"),
            styles: [__webpack_require__(/*! ./content-layout-page.component.scss */ "./src/app/pages/content-layout-page/content-layout-page.component.scss")]
        })
    ], ContentLayoutPageComponent);
    return ContentLayoutPageComponent;
}());



/***/ }),

/***/ "./src/app/pages/content-layout-page/content-pages-routing.module.ts":
/*!***************************************************************************!*\
  !*** ./src/app/pages/content-layout-page/content-pages-routing.module.ts ***!
  \***************************************************************************/
/*! exports provided: ContentPagesRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContentPagesRoutingModule", function() { return ContentPagesRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _content_layout_page_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./content-layout-page.component */ "./src/app/pages/content-layout-page/content-layout-page.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: '',
        component: _content_layout_page_component__WEBPACK_IMPORTED_MODULE_2__["ContentLayoutPageComponent"],
        data: {
            title: 'Content Layout page'
        },
    }
];
var ContentPagesRoutingModule = /** @class */ (function () {
    function ContentPagesRoutingModule() {
    }
    ContentPagesRoutingModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]],
        })
    ], ContentPagesRoutingModule);
    return ContentPagesRoutingModule;
}());



/***/ }),

/***/ "./src/app/pages/content-layout-page/content-pages.module.ts":
/*!*******************************************************************!*\
  !*** ./src/app/pages/content-layout-page/content-pages.module.ts ***!
  \*******************************************************************/
/*! exports provided: ContentPagesModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContentPagesModule", function() { return ContentPagesModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _content_pages_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./content-pages-routing.module */ "./src/app/pages/content-layout-page/content-pages-routing.module.ts");
/* harmony import */ var _content_layout_page_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./content-layout-page.component */ "./src/app/pages/content-layout-page/content-layout-page.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};





var ContentPagesModule = /** @class */ (function () {
    function ContentPagesModule() {
    }
    ContentPagesModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _content_pages_routing_module__WEBPACK_IMPORTED_MODULE_3__["ContentPagesRoutingModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"]
            ],
            declarations: [
                _content_layout_page_component__WEBPACK_IMPORTED_MODULE_4__["ContentLayoutPageComponent"]
            ]
        })
    ], ContentPagesModule);
    return ContentPagesModule;
}());



/***/ })

}]);
//# sourceMappingURL=pages-content-layout-page-content-pages-module.js.map